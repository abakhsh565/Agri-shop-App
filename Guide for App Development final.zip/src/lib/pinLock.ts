// Device-level quick-unlock PIN.
//
// The authoritative sign-in is Supabase phone OTP (see lib/auth.ts). The PIN is
// only a convenience lock for re-entry on THIS device, so it lives in
// localStorage — never sent to the server. We still avoid storing it in the
// clear: we keep a SHA-256 digest of `userId:pin`. (A future migration can move
// to a server-side Argon2id hash; this keeps the device lock working today
// without any mock users.)

const KEY = (userId: string) => `agri_pin_${userId}`;

async function digest(userId: string, pin: string): Promise<string> {
  const data = new TextEncoder().encode(`${userId}:${pin}`);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export async function savePin(userId: string, pin: string): Promise<void> {
  localStorage.setItem(KEY(userId), await digest(userId, pin));
}

export function hasPin(userId: string): boolean {
  return localStorage.getItem(KEY(userId)) !== null;
}

export async function verifyPin(userId: string, pin: string): Promise<boolean> {
  const stored = localStorage.getItem(KEY(userId));
  // If no PIN was ever set on this device, don't trap the user out.
  if (!stored) return true;
  return stored === (await digest(userId, pin));
}

export function clearPin(userId: string): void {
  localStorage.removeItem(KEY(userId));
}
