import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { type ReactNode } from "react";

interface NavHeaderProps {
  title: string;
  backLabel?: string;
  backTo?: string;
  onBack?: () => void;
  right?: ReactNode;
  noBack?: boolean;
}

export default function NavHeader({ title, backLabel, backTo, onBack, right, noBack }: NavHeaderProps) {
  const navigate = useNavigate();

  function handleBack() {
    if (onBack) { onBack(); return; }
    if (backTo) { navigate(backTo); return; }
    navigate(-1);
  }

  return (
    <div
      className="flex h-11 items-center px-4 relative shrink-0 w-full"
      style={{ background: "var(--background)" }}
    >
      {!noBack && (
        <button
          onClick={handleBack}
          className="flex items-center gap-1 text-sm font-medium absolute left-4 transition-opacity active:opacity-60"
          style={{ color: "var(--text-primary)" }}
        >
          <ArrowLeft size={18} />
          {backLabel && <span>{backLabel}</span>}
        </button>
      )}
      <p
        className="text-base font-bold w-full text-center"
        style={{ color: "var(--text-primary)" }}
      >
        {title}
      </p>
      {right && <div className="absolute right-4">{right}</div>}
    </div>
  );
}
