import { createBrowserRouter, Navigate } from "react-router-dom";
import ProtectedRoute from "@/components/auth/ProtectedRoute";

// Auth
import SplashPage from "@/pages/auth/SplashPage";
import LoginPage from "@/pages/auth/LoginPage";
import OTPVerifyPage from "@/pages/auth/OTPVerifyPage";
import PINSetPage from "@/pages/auth/PINSetPage";
import NotRegisteredPage from "@/pages/auth/NotRegisteredPage";
import DeactivatedPage from "@/pages/auth/DeactivatedPage";

// Layout
import EmployeeLayout from "@/components/layout/EmployeeLayout";
import AdminLayout from "@/components/layout/AdminLayout";

// Admin pages
import AdminDashboardPage from "@/pages/admin/dashboard/AdminDashboardPage";
import AdminSalesListPage from "@/pages/admin/sales/AdminSalesListPage";
import AdminSaleDetailPage from "@/pages/admin/sales/AdminSaleDetailPage";
import AdminInventoryPage from "@/pages/admin/inventory/AdminInventoryPage";
import MoreMenuPage from "@/pages/admin/more/MoreMenuPage";
import EmployeesListPage from "@/pages/admin/employees/EmployeesListPage";
import EmployeeDetailPage from "@/pages/admin/employees/EmployeeDetailPage";
import CompaniesListPage from "@/pages/admin/companies/CompaniesListPage";
import AddCompanyPage from "@/pages/admin/companies/AddCompanyPage";
import CompanyDetailPage from "@/pages/admin/companies/CompanyDetailPage";
import AdminSettingsPage from "@/pages/admin/settings/AdminSettingsPage";
import AdminNotificationsPage from "@/pages/admin/notifications/AdminNotificationsPage";
import AddEmployeePage from "@/pages/admin/employees/AddEmployeePage";
import AdminPurchasesPage from "@/pages/admin/purchases/AdminPurchasesPage";
import RecordPurchasePage from "@/pages/admin/purchases/RecordPurchasePage";
import AdminPaymentsPage from "@/pages/admin/payments/AdminPaymentsPage";
import RecordSupplierPaymentPage from "@/pages/admin/payments/RecordSupplierPaymentPage";
import AdminReportsPage from "@/pages/admin/reports/AdminReportsPage";
import InventoryAdjustPage from "@/pages/admin/inventory/InventoryAdjustPage";
import AddProductPage from "@/pages/admin/inventory/AddProductPage";

// Employee pages
import DashboardPage from "@/pages/employee/dashboard/DashboardPage";
import SelectCustomerPage from "@/pages/employee/sale/SelectCustomerPage";
import BrowseProductsPage from "@/pages/employee/sale/BrowseProductsPage";
import VariantSelectorPage from "@/pages/employee/sale/VariantSelectorPage";
import CartPage from "@/pages/employee/sale/CartPage";
import SaleReviewPage from "@/pages/employee/sale/SaleReviewPage";
import SaleSuccessPage from "@/pages/employee/sale/SaleSuccessPage";
import SalesListPage from "@/pages/employee/sales/SalesListPage";
import SaleDetailPage from "@/pages/employee/sales/SaleDetailPage";
import CustomersListPage from "@/pages/employee/customers/CustomersListPage";
import CustomerProfilePage from "@/pages/employee/customers/CustomerProfilePage";
import CustomerPurchaseHistoryPage from "@/pages/employee/customers/CustomerPurchaseHistoryPage";
import CustomerPaymentHistoryPage from "@/pages/employee/customers/CustomerPaymentHistoryPage";
import RecordCustomerPaymentPage from "@/pages/employee/customers/RecordCustomerPaymentPage";
import AddCustomerPage from "@/pages/employee/customers/AddCustomerPage";
import ProductsListPage from "@/pages/employee/products/ProductsListPage";
import ProductDetailPage from "@/pages/employee/products/ProductDetailPage";
import ReturnSelectItemsPage from "@/pages/employee/returns/ReturnSelectItemsPage";
import ReturnConfirmPage from "@/pages/employee/returns/ReturnConfirmPage";
import ReturnSuccessPage from "@/pages/employee/returns/ReturnSuccessPage";
import SearchPage from "@/pages/employee/search/SearchPage";
import SettingsPage from "@/pages/employee/settings/SettingsPage";
import ActivityLogPage from "@/pages/employee/activity/ActivityLogPage";

export const router = createBrowserRouter([
  { path: "/", element: <SplashPage /> },
  { path: "/login", element: <LoginPage /> },
  { path: "/login/otp", element: <OTPVerifyPage /> },
  { path: "/login/pin-set", element: <PINSetPage /> },
  { path: "/login/not-registered", element: <NotRegisteredPage /> },
  { path: "/login/deactivated", element: <DeactivatedPage /> },

  {
    element: <ProtectedRoute allowedRoles={["admin", "co_admin"]} />,
    children: [{
    path: "/admin",
    element: <AdminLayout />,
    children: [
      { index: true, element: <Navigate to="/admin/dashboard" replace /> },
      { path: "dashboard",  element: <AdminDashboardPage /> },
      { path: "sale",       element: <SelectCustomerPage /> },
      { path: "sale/products", element: <BrowseProductsPage /> },
      { path: "sale/products/:productId", element: <VariantSelectorPage /> },
      { path: "sale/cart",  element: <CartPage /> },
      { path: "sale/review", element: <SaleReviewPage /> },
      { path: "sale/success", element: <SaleSuccessPage /> },
      { path: "sales",      element: <AdminSalesListPage /> },
      { path: "sales/:saleId", element: <AdminSaleDetailPage /> },
      { path: "inventory",  element: <AdminInventoryPage /> },
      { path: "inventory/new", element: <AddProductPage /> },
      { path: "inventory/:productId/edit", element: <AddProductPage /> },
      { path: "inventory/:productId/adjust", element: <InventoryAdjustPage /> },
      { path: "customers",  element: <CustomersListPage /> },
      { path: "customers/new", element: <AddCustomerPage /> },
      { path: "customers/:customerId", element: <CustomerProfilePage /> },
      { path: "customers/:customerId/purchases", element: <CustomerPurchaseHistoryPage /> },
      { path: "customers/:customerId/payments",  element: <CustomerPaymentHistoryPage /> },
      { path: "customers/:customerId/record-payment", element: <RecordCustomerPaymentPage /> },
      { path: "more",       element: <MoreMenuPage /> },
      { path: "employees",  element: <EmployeesListPage /> },
      { path: "employees/new", element: <AddEmployeePage /> },
      { path: "employees/:employeeId", element: <EmployeeDetailPage /> },
      { path: "companies",  element: <CompaniesListPage /> },
      { path: "companies/new", element: <AddCompanyPage /> },
      { path: "companies/:companyId", element: <CompanyDetailPage /> },
      { path: "settings",   element: <AdminSettingsPage /> },
      { path: "activity",   element: <ActivityLogPage /> },
      { path: "notifications", element: <AdminNotificationsPage /> },
      { path: "products",   element: <ProductsListPage /> },
      { path: "products/:productId", element: <ProductDetailPage /> },
      { path: "purchases",  element: <AdminPurchasesPage /> },
      { path: "purchases/new", element: <RecordPurchasePage /> },
      { path: "reports",    element: <AdminReportsPage /> },
      { path: "payments",   element: <AdminPaymentsPage /> },
      { path: "payments/supplier/:companyId", element: <RecordSupplierPaymentPage /> },
    ],
  }],
  },

  {
    element: <ProtectedRoute />,
    children: [{
    path: "/employee",
    element: <EmployeeLayout />,
    children: [
      { index: true, element: <Navigate to="/employee/dashboard" replace /> },
      { path: "dashboard", element: <DashboardPage /> },
      { path: "sale", element: <SelectCustomerPage /> },
      { path: "sale/products", element: <BrowseProductsPage /> },
      { path: "sale/products/:productId", element: <VariantSelectorPage /> },
      { path: "sale/cart", element: <CartPage /> },
      { path: "sale/review", element: <SaleReviewPage /> },
      { path: "sale/success", element: <SaleSuccessPage /> },
      { path: "sales", element: <SalesListPage /> },
      { path: "sales/:saleId", element: <SaleDetailPage /> },
      { path: "sales/:saleId/return", element: <ReturnSelectItemsPage /> },
      { path: "sales/:saleId/return/confirm", element: <ReturnConfirmPage /> },
      { path: "sales/:saleId/return/success", element: <ReturnSuccessPage /> },
      { path: "customers", element: <CustomersListPage /> },
      { path: "customers/new", element: <AddCustomerPage /> },
      { path: "customers/:customerId", element: <CustomerProfilePage /> },
      { path: "customers/:customerId/purchases", element: <CustomerPurchaseHistoryPage /> },
      { path: "customers/:customerId/payments", element: <CustomerPaymentHistoryPage /> },
      { path: "customers/:customerId/record-payment", element: <RecordCustomerPaymentPage /> },
      { path: "products", element: <ProductsListPage /> },
      { path: "products/:productId", element: <ProductDetailPage /> },
      { path: "search", element: <SearchPage /> },
      { path: "settings", element: <SettingsPage /> },
      { path: "activity", element: <ActivityLogPage /> },
    ],
  }],
  },
]);
